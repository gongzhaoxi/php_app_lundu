<template>
    <view :class="themeName">
        <!-- 首次加载 -->
        <w-loading v-if="isFirstLoading" />
        <!-- 文章详情 -->
        <view class="layout-detail-widget">
            <view class="header">
                <view class="pb-30 u-text-center">{{ detail.name }}</view>
                <view class="flex justify-between">
                    <view class="font-xs font-weight-thin color-main"></view>
                    <view class="font-xs font-weight-thin color-main">天气：{{ detail.weather }}</view>
                </view>
            </view>
            <view class="content">
				<view v-if="userInfo.role_id != 1">
					<u-row gutter="16" justify="center" v-if="detail.status == 0">
						<u-col span="6" >
							<view class="u-text-center"><u-button @click="push" type="success" size="medium">推送保存</u-button></view>
						</u-col>
						<u-col span="6">
							<view class="u-text-center"><u-button @click="flow" type="warning" size="medium">获取人车数</u-button></view>
						</u-col>
					</u-row>
					<u-row gutter="16" justify="center" v-if="detail.status == 1">
						<u-col span="6" >
							<view class="u-text-center"><u-button @click="push" type="success" size="medium">推送保存</u-button></view>
						</u-col>
						<u-col span="6">

						</u-col>
					</u-row>					
				</view>
				<view v-if="userInfo.role_id == 1 && detail.status == 1">
					<u-row gutter="16" justify="center">
						<u-col span="6" >
							
						</u-col>
						<u-col span="6">
							<view class="u-text-right"><u-button @click="confirm" type="success" size="medium">确认</u-button></view>
						</u-col>
					</u-row>
				</view>				
				<view class="u-m-20">
					<u-form :model="form" ref="form1" label-width="150">
						<u-form-item label="车辆数量" prop="car_num">
							<view class="u-flex">
								<view class="u-flex-1 u-text-center"><u-button @click="minus('car_num')" :custom-style="customStyle">-</u-button></view>
								<view class="u-flex-3 u-text-center"><u-input  v-model="form.car_num" type="number" :border="true" /></view>
								<view class="u-flex-1 u-text-center"><u-button @click="plus('car_num')" :custom-style="customStyle">+</u-button></view>
							</view>
						</u-form-item>
						
						<u-form-item label="行人数量" prop="human_num">
							<view class="u-flex">
								<view class="u-flex-1 u-text-center"><u-button @click="minus('human_num')" :custom-style="customStyle">-</u-button></view>
								<view class="u-flex-3 u-text-center"><u-input  v-model="form.human_num" type="number" :border="true" /></view>
								<view class="u-flex-1 u-text-center"><u-button @click="plus('human_num')" :custom-style="customStyle">+</u-button></view>
							</view>
						</u-form-item>
								
						<u-form-item label="车内人数" prop="car_human_num">
							<view class="u-flex">
								<view class="u-flex-1 u-text-center"><u-button @click="minus('car_human_num')" :custom-style="customStyle">-</u-button></view>
								<view class="u-flex-3 u-text-center"><u-input v-model="form.car_human_num" type="number" :border="true" /></view>
								<view class="u-flex-1 u-text-center"><u-button @click="plus('car_human_num')" :custom-style="customStyle">+</u-button></view>
							</view>
						</u-form-item>
						<u-form-item label="" label-width="0" >
							<view style="width:100%;">
								<u-row gutter="16" justify="center">
									<u-col span="4" >
										合计：
									</u-col>
									<u-col span="4">
										车次：{{form.car_num}}
									</u-col>
									<u-col span="4">
										人次：{{(form.human_num?parseInt(form.human_num):0)+(form.car_human_num?parseInt(form.car_human_num):0)}}
									</u-col>					
								</u-row>
							</view>
						</u-form-item>
						<u-form-item label="船号" prop="remark">
							<u-input v-model="form.remark" type="textarea" :border="true" />
						</u-form-item>
						<u-form-item label="提交人" prop="push_by" v-if="form.push_by">
							<u-input v-model="form.push_by" type="text" :disabled="true" :border="true" />
						</u-form-item>
						<u-form-item label="提交时间" prop="push_time" v-if="form.push_time">
							<u-input v-model="form.push_time" type="text" :disabled="true" :border="true" />
						</u-form-item>		
						<u-form-item label="确认人" prop="confirm_by" v-if="form.confirm_by">
							<u-input v-model="form.confirm_by" type="text" :disabled="true" :border="true" />
						</u-form-item>
						<u-form-item label="确认时间" prop="confirm_time" v-if="form.confirm_time">
							<u-input v-model="form.confirm_time" type="text" :disabled="true" :border="true" />
						</u-form-item>										
					</u-form>
				</view>
            </view>
        </view>
    </view>
</template>

<script setup>
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import sailingApi from '@/api/sailingApi'
import { useUserStore } from '@/stores/userStore'
import { storeToRefs } from 'pinia'
const userStore = useUserStore()
const { userInfo } = storeToRefs(userStore);
// 首次加载
const isFirstLoading = ref(true)
const form = ref({
	id:'',
	car_num:'',
	human_num:'',
	car_human_num:'',
	weather:'',
	remark:'',
})
// 文章详情
const detail = ref({})

const customStyle =  {
	height: '2.3rem',
	lineHeight: '2.3rem',
}
const isGetFlow = ref(false)

onLoad(async (options) => {
    const id = parseInt(options.id)
	form.value.id = options.id;
    detail.value = await sailingApi.detail(id);
	form.value.weather = detail.value.weather;
	form.value.remark = detail.value.remark;
	if(detail.value.status >= 1){
		form.value.car_num = detail.value.car_num;
		form.value.human_num = detail.value.human_num;
		form.value.car_human_num = detail.value.car_human_num;
		form.value.remark = detail.value.remark;
		form.value.push_time = detail.value.push_time;
		form.value.push_by = detail.value.push_by;
		form.value.confirm_by = detail.value.confirm_by;
		form.value.confirm_time = detail.value.confirm_time;
	}
    isFirstLoading.value = false
})
const flow = async(e) => {
	if(isGetFlow.value == true){
		return;
	}
	uni.showLoading({
		title: "加载中"
	});
	var res  = await sailingApi.flow({id:form.value.id});	
	form.value.car_num = (form.value.car_num?parseInt(form.value.car_num):0) + parseInt(res.car_num);
	form.value.human_num = (form.value.human_num?parseInt(form.value.human_num):0) + parseInt(res.human_num);
	form.value.car_human_num = (form.value.car_num?parseInt(form.value.car_num):0) + parseInt(res.car_num);
	isGetFlow.value = true;
}
const push = async() => {
	if(!form.value.car_human_num){
		//uni.$u.toast('请获取人车数');
		//return;
	}
	await sailingApi.push(form.value);
	uni.$u.toast('保存成功');
	setTimeout(function(){
		uni.navigateBack();
	},2000)
}
const confirm = async() => {
	await sailingApi.confirm(form.value);
	uni.$u.toast('保存成功');
	setTimeout(function(){
		uni.navigateBack();
	},2000)
}
const minus = async(k) => {
	if(form.value[k]){
		if(form.value[k] > 1){
			form.value[k] = form.value[k] -1;
		}
	}
}
const plus = async(k) => {
	form.value[k] = (form.value[k]?parseInt(form.value[k]):0) + 1;
}
</script>

<style lang="scss">
page { background: #ffffff; }
.layout-detail-widget {
    .header {
        padding: 30rpx;
        font-size: 36rpx;
        font-weight: bold;
        color: #333333;
        border-bottom: 1rpx solid #f2f2f2;
    }
    .content {
        margin: 30rpx 20rpx;
        padding-bottom: 10rpx;
    }
}
</style>
