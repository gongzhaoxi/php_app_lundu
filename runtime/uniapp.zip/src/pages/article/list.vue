<template>
    <view :class="themeName">
        <z-paging-swiper>
            <template #top>
				 <view class="layout-input-widget">
					<view class="u-flex u-row-between">
						<view>
							<u-input placeholder="选择日期" @click="showDate = true"  v-model="sailing_date" type="select" :border="true" />
						</view>
						<u-button size="medium" type="success"  @click="$go('/pages/article/create')">增加班次</u-button>
					</view>
				 </view>
            </template>
            <swiper  :current="0" :style="{ height: '100%' }" >
                <swiper-item >
					<z-paging
						ref="paging"
						v-model="dataList"
						auto-show-back-to-top
						:auto="false"
						:data-key="0"
						:fixed="false"
						height="100%"
						@query="queryArticleList"
					>
						<view class="layout-article-widget">
							<view v-for="(item, index) in dataList" :key="index" class="item">
								<view class="flex flex-1 flex-col justify-between px-20" @click="$go('/pages/article/edit?id='+item.id)">
									<view class="flex justify-between">
										<view class="font-sm color-muted">{{ index+1 }}.{{ item.name }}</view>
										<view class="font-sm color-muted"><view  style="text-align: center;"><u-icon color="#2979ff"  name="edit-pen"></u-icon></view></view>
									</view>
									<view class="font-xs color-muted u-m-t-20">
										{{ item.remark }}
									</view>
								</view>
							</view>
						</view>
					</z-paging>
                </swiper-item>
            </swiper>
        </z-paging-swiper>
		<u-calendar v-model="showDate" @change="changeDate" mode="date"></u-calendar>
    </view>
</template>

<script setup>
import { ref, nextTick } from 'vue'
import { onLoad ,onShow} from '@dcloudio/uni-app'
import sailingApi from '@/api/sailingApi'
// 参数定义
const showDate = ref(false)
const sailing_date = ref('')
const paging = ref(null)
const isFirst = ref(false)
const dataList = ref([])

const changeDate = async(e) => {
	sailing_date.value = e.result;
	await queryArticleList(1);
}

const queryArticleList = async (pageNo) => {
    let params = {
        sailing_date: sailing_date.value,
        pageNo: pageNo
    }
    sailingApi.lists(params).then(res => {
        paging.value.complete(res.data)
        isFirst.value = true
    }).catch(() => {
        paging.value.complete(false)
    })
}
onLoad(async () => {
	var today = new Date();
	//日期
	var DD = String(today.getDate()).padStart(2, '0'); // 获取日
	var MM = String(today.getMonth() + 1).padStart(2, '0'); //获取月份，1 月为 0
	var yyyy = today.getFullYear(); // 获取年
	sailing_date.value = yyyy + '-'+ MM + '-' + DD   ;
})
onShow(async () => {
	await queryArticleList(1);
})
</script>

<style lang="scss" scoped>
.layout-input-widget {
    padding: 12rpx 20rpx;
    border-bottom: 1px solid #f2f2f2;
    background-color: #ffffff;
}
.layout-article-widget {
    margin-top: 20rpx;
    .item {
        display: flex;
        justify-content: space-between;
        padding: 20rpx;
        border-bottom: 1rpx dashed #f2f2f2;
        background-color: #ffffff;
    }
}
</style>