<template>
    <view :class="themeName">
        <!-- 首次加载 -->
        <w-loading v-if="isFirstLoading" />
        <view class="u-m-20">
			<u-form :model="form" ref="form1" label-width="150">
				<u-form-item label="班次名称" prop="name">
					<u-input v-model="form.name" type="select" @click="showSelect=true" :border="true" />
				</u-form-item>
				<u-form-item label="船号" prop="remark">
					<u-input v-model="form.remark"  :border="true" />
				</u-form-item>
			</u-form>
			<u-button  type="success"  @click="submit">提交</u-button>
        </view>
		<u-select v-model="showSelect" :list="shippingLine" label-name="name" value-name="id" @confirm="confirmSelect"></u-select>
    </view>
</template>

<script setup>
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import sailingApi from '@/api/sailingApi'
const isFirstLoading = ref(true)
const shippingLine = ref([])
const form = ref({
	name:'',
	shipping_line_id:'',
	remark:"",
})
const showSelect = ref(false)
const confirmSelect = (e) => {
	form.value.name = e[0]['label'];
	form.value.shipping_line_id = e[0]['value'];
}
onLoad(async (options) => {
    shippingLine.value = await sailingApi.shippingLine()
    isFirstLoading.value = false
})
const submit = async() => {
	if(!form.value.name){
		uni.$u.toast('请选择班次');
		return;
	}
	await sailingApi.create(form.value);
	uni.$u.toast('保存成功');
	setTimeout(function(){
		uni.navigateBack();
	},2000)
}
</script>

<style lang="scss">
page { background: #ffffff; }
.layout-detail-widget {
    .header {
        padding: 30rpx;
        font-size: 36rpx;
        font-weight: bold;
        color: #333333;
        border-bottom: 1rpx solid #f2f2f2;
    }
    .content {
        margin: 30rpx 20rpx;
        padding-bottom: 10rpx;
    }
}
</style>
