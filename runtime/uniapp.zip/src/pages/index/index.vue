<template>
    <view :class="themeName">
        <z-paging-swiper>
            <template #top>
				 <view class="layout-input-widget">
					<view class="u-flex u-row-between">
						<view>
							<u-input placeholder="选择日期" @click="showDate = true"  v-model="sailing_date" type="select" :border="true" />
						</view>
						<view style="padding-left:20px;">
							<u-input placeholder="状态" @click="showStatus = true"  v-model="statusText" type="select" :border="true" />
						</view>
					</view>
				 </view>
            </template>
            <swiper  :current="0" :style="{ height: '100%' }" >
                <swiper-item >
					<z-paging
						ref="paging"
						v-model="dataList"
						auto-show-back-to-top
						:auto="false"
						:data-key="0"
						:fixed="false"
						height="100%"
						@query="queryArticleList"
					>
						<view class="layout-article-widget">
							<view v-for="(item, index) in dataList" :key="index" class="item" @click="$go('/pages/article/detail?id='+item.id)">
								<view class="u-m-b-4">
									<u-row gutter="16" justify="center">
										<u-col span="3">
											<view class="label">班次时间:</view>
										</u-col>
										<u-col span="6">
											<view class="value">{{item.sailing_time}}</view>
										</u-col>										
										<u-col span="3">
											<view class="label">{{item.status_text}}</view>
										</u-col>
									</u-row>
								</view>
								<view class="u-m-b-4">
									<u-row gutter="16" justify="center">
										<u-col span="3">
											<view class="label">班次名称:</view>
										</u-col>
										<u-col span="9">
											<view class="value">{{item.name}}</view>
										</u-col>
									</u-row>
								</view>
								<view class="u-m-b-4">
									<u-row gutter="16" justify="center">
										<u-col span="3">
											<view class="label">船号:</view>
										</u-col>
										<u-col span="9">
											<view class="value">{{item.remark}}</view>
										</u-col>
									</u-row>
								</view>
								<view>
									<u-row gutter="16" justify="center">
										<u-col span="3">
											<view class="label">人次:</view>
										</u-col>
										<u-col span="3">
											<view class="value">{{item.human_total_num}}</view>
										</u-col>
										<u-col span="3">
											<view class="label">车次:</view>
										</u-col>
										<u-col span="3">
											<view class="value">{{item.car_num}}</view>
										</u-col>									
									</u-row>	
								</view>							
							</view>
						</view>
					</z-paging>
                </swiper-item>
            </swiper>
        </z-paging-swiper>
		<u-calendar v-model="showDate" @change="changeDate" mode="date"></u-calendar>
		<u-select v-model="showStatus" :list="statusOption" :default-value="[statusSelect]" label-name="label" value-name="value" @confirm="confirmStatus"></u-select>
	</view>
</template>

<script setup>
import { ref, nextTick,computed  } from 'vue'
import { onLoad ,onShow} from '@dcloudio/uni-app'
import sailingApi from '@/api/sailingApi'
import { useUserStore } from '@/stores/userStore'
import { storeToRefs } from 'pinia'
const userStore = useUserStore()
const { userInfo } = storeToRefs(userStore);
// 参数定义
const showDate = ref(false)
const sailing_date = ref('')
const paging = ref(null)
const isFirst = ref(false)
const dataList = ref([])
const showStatus = ref(false)
const status = ref(null)
const statusOption = ref([])
console.log(userInfo)
if(userInfo.value.role_id == 1){
	status.value = 1;
}else{
	status.value = 0;
}
const changeDate = async(e) => {
	sailing_date.value = e.result;
	await queryArticleList(1);
}

const queryArticleList = async (pageNo) => {
    let params = {
        sailing_date: sailing_date.value,
		status: status.value,
        pageNo: pageNo
    }
    sailingApi.lists(params).then(res => {
        paging.value.complete(res.data)
        isFirst.value = true
    }).catch(() => {
        paging.value.complete(false)
    })
}
onLoad(async () => {
	var today = new Date();
	//日期
	var DD = String(today.getDate()).padStart(2, '0'); // 获取日
	var MM = String(today.getMonth() + 1).padStart(2, '0'); //获取月份，1 月为 0
	var yyyy = today.getFullYear(); // 获取年
	sailing_date.value = yyyy + '-'+ MM + '-' + DD   ;
	var params =  await sailingApi.params();
	statusOption.value = params.status;

})
onShow(async () => {
	await queryArticleList(1);
})
const confirmStatus = async(e) => {
	status.value = e[0]['value'];
	await queryArticleList(1);
}

let statusSelect = computed(() => {
	var index = 0;
	for (var i = 0; i < statusOption.value.length; i++) {
		if(statusOption.value[i].value === status.value){
			index = i;
		}
	}
	return index;
});
let statusText = computed(() => {
	var text = '';
	for (var i = 0; i < statusOption.value.length; i++) {
		if(statusOption.value[i].value === status.value){
			text = statusOption.value[i].label;
		}
	}
	return text;
});
</script>

<style lang="scss" scoped>
.layout-input-widget {
    padding: 12rpx 20rpx;
    border-bottom: 1px solid #f2f2f2;
    background-color: #ffffff;
}
.layout-article-widget {
    margin-top: 20rpx;
	padding: 0 20rpx;
    .item {
        padding: 20rpx;
        margin-bottom:20rpx;
        background-color: #00b27b;
		.label{
			color:#fff;
		}
		.value{
			color:#ff0000;
		}
    }
}
</style>