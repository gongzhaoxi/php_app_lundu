<template>
    <view :class="themeName">
        <!-- 首次加载 -->
        <w-loading v-if="isFirstLoading" />
        <view class="u-p-20 ">
			<u-table>
				<u-tr>
					<u-th>序号</u-th>
					<u-th>班次名称</u-th>
					<u-th>操作</u-th>
				</u-tr>
				<u-tr>
					<u-td>1</u-td>
					<u-td>二年级</u-td>
					<u-td>22</u-td>
				</u-tr>
				<u-tr>
					<u-td>2</u-td>
					<u-td>05班</u-td>
					<u-td>20</u-td>
				</u-tr>
			</u-table>
        </view>
    </view>
</template>

<script setup>
import { ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'
import { storeToRefs } from 'pinia'
import { useUserStore } from '@/stores/userStore'
import designApi from '@/api/designApi'
import userApi from '@/api/userApi'

// 首次加载
const isFirstLoading = ref(true)

// 登录状态
const userStore = useUserStore()
const { isLogin } = storeToRefs(userStore)

// 参数定义
const userInfo = ref({})   // 用户信息
const diyService = ref({}) // 服务工具
const diyAdv = ref({})     // 轮播广告

onShow(async () => {
    const diyItems = await designApi.diyMe()
    diyAdv.value = diyItems.adv
    diyService.value = diyItems.service

    if (isLogin.value) {
        userInfo.value = await userApi.center()
    }
    isFirstLoading.value = false
})
</script>

<style lang="scss" scoped>
.layout-header-widget {
    min-height: 180rpx;
    background: url("../../static/bg_head_radiant.png");
    background-position: center right;
    background-repeat: no-repeat;
    background-size: auto 100%;
    background-color: var(--theme-background);
    .grid-skinny-unit {
        display: flex;
        justify-content: space-between;
        padding: 30rpx;
        .synopsis {
            display: flex;
            flex: 1;
            flex-direction: column;
            justify-content: space-between;
            margin-left: 20rpx;
            padding: 10rpx 0;
            height: 100%;
        }
        .login {
            margin-left: 20rpx;
            padding: 8rpx;
            width: 170rpx;
            font-size: 28rpx;
            color: #ffffff;
            border: 2rpx solid #ffffff;
            border-radius: 50rpx;
            text-align: center;
        }
        .icon {
            margin-top: 14rpx;
            margin-right: 20rpx;
        }
    }
}
</style>
