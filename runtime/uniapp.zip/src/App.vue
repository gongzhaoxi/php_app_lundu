<script setup>
import { getCurrentInstance } from 'vue'
import { onLaunch } from '@dcloudio/uni-app'
import { useAppStore } from '@/stores/appStore'
import { useUserStore } from '@/stores/userStore'
import { storeToRefs } from 'pinia'
const appStore = useAppStore()
const userStore = useUserStore()
const { proxy } = getCurrentInstance()

onLaunch(async () => {
    //uni.hideTabBar({
        //animation: false,
        //fail() {}
    //})
    await appStore.getSysConfig()
    await appStore.h5Intercepts()
    await userStore.getUserInfo()
	
	const { isLogin,userInfo } = storeToRefs(userStore)
	if(!isLogin.value){
		uni.navigateTo({
		    url: '/pages/login/enroll'
		})
	}
    proxy.$isResolve()
})
</script>

<style lang="scss">
// #ifdef H5
* { touch-action: pan-y; }
// #endif
</style>
