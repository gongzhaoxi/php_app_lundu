export default class {

    static shippingLine() {
        return uni.$u.http.get('sailing/shippingLine')
    }

    static create(params) {
        return uni.$u.http.post('sailing/create', params)
    }

    static lists(params) {
        return uni.$u.http.get('sailing/lists', params)
    }

    static detail(id) {
        return uni.$u.http.get('sailing/detail', { id })
    }
	
	static update(params) {
	    return uni.$u.http.post('sailing/update', params)
	}
	
	static params() {
	    return uni.$u.http.get('sailing/params')
	}
	
	static flow(params) {
		console.log(params);
	    return uni.$u.http.get('sailing/flow',params)
	}	
	
	static push(params) {
	    return uni.$u.http.post('sailing/push', params)
	}
	
	static confirm(params) {
	    return uni.$u.http.post('sailing/confirm', params)
	}	
}
